# -*- coding: iso-8859-1 -*-
__program__ = "Album Cover Art Downloader"
__author__ = "Sami Ky�stil� <skyostil@kempele.fi>"
__version__ = "1.3"
__copyright__ = "Copyright (c) 2003, 2004 by Sami Ky�stil�"
__license__ = "GPL"
