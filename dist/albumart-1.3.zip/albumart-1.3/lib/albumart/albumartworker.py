#
# A simple dialog for showing progress information.
#

from albumartworkerdialog import AlbumArtWorkerDialog

class AlbumArtWorker(AlbumArtWorkerDialog):
	def __init__(self,parent = None,name = None,fl = 0):
		AlbumArtWorkerDialog.__init__(self,parent,name,fl)
		self.show()

	def message(self, msg):
		self.statusLabel.setText(msg)

