?package(albumart):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="albumart" command="/usr/bin/albumart"
