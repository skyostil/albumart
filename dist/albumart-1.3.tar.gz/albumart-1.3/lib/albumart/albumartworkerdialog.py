# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '../../src/albumartworkerdialog.ui'
#
# Created: ke touko  12 00:38:01 2004
#      by: The PyQt User Interface Compiler (pyuic) 3.11
#
# WARNING! All changes made in this file will be lost!


from qt import *


class AlbumArtWorkerDialog(QDialog):
    def __init__(self,parent = None,name = None,modal = 0,fl = 0):
        QDialog.__init__(self,parent,name,modal,fl)

        if not name:
            self.setName("AlbumArtWorkerDialog")

        self.setSizeGripEnabled(1)

        AlbumArtWorkerDialogLayout = QVBoxLayout(self,11,6,"AlbumArtWorkerDialogLayout")

        self.statusLabel = QLabel(self,"statusLabel")
        AlbumArtWorkerDialogLayout.addWidget(self.statusLabel)

        self.progressBar = QProgressBar(self,"progressBar")
        AlbumArtWorkerDialogLayout.addWidget(self.progressBar)

        self.line1 = QFrame(self,"line1")
        self.line1.setFrameShape(QFrame.HLine)
        self.line1.setFrameShadow(QFrame.Sunken)
        self.line1.setFrameShape(QFrame.HLine)
        AlbumArtWorkerDialogLayout.addWidget(self.line1)

        Layout1 = QHBoxLayout(None,0,6,"Layout1")
        Horizontal_Spacing2 = QSpacerItem(20,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        Layout1.addItem(Horizontal_Spacing2)

        self.buttonCancel = QPushButton(self,"buttonCancel")
        self.buttonCancel.setAutoDefault(1)
        Layout1.addWidget(self.buttonCancel)
        AlbumArtWorkerDialogLayout.addLayout(Layout1)

        self.languageChange()

        self.resize(QSize(378,122).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.buttonCancel,SIGNAL("clicked()"),self,SLOT("reject()"))


    def languageChange(self):
        self.setCaption(self.__tr("Task Progress"))
        self.statusLabel.setText(self.__tr("Working..."))
        self.buttonCancel.setText(self.__tr("&Cancel"))
        self.buttonCancel.setAccel(QString.null)


    def __tr(self,s,c = None):
        return qApp.translate("AlbumArtWorkerDialog",s,c)
