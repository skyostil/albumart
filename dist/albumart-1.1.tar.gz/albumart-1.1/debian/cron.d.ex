#
# Regular cron jobs for the albumart package
#
0 4	* * *	root	albumart_maintenance
